Implementation Language: JAVA
Preferrable IDE: Windows command prompt


Structure of file in SentiProject Unzipped folder should be:-
Relative Path - File Name
.  			  - Senti_CheckPolarity.jar
.  			  - Senti_NBC.jar
.  			  - Senti_Summarization.jar
./lib		  - Required Stanford Parser and WordNet Synonym jars.  "jaws-bin.jar","jaws-src-1.2.jar","stanford-postagger-2010-05-26.jar"
./src/models  - Required Stanford Parser
./src/data    - All the input datafiles and output results file. 
				-> Input files
				.data (Review File)
				.ft (Manually selected comma separated feature file)
				.gold (Manually agreed Gold standard File)
				-> Intermediate Output files
				.out (Tagged File with POS Tagger)
				.arff (Intermediate file for NBC Classifier)
				-> Output Files
				.res (Result output file for CheckPolarity algorithm)
				.sum (Feature wise summarized output)

General Setup Instructions:-
1. Locate the file "SentiProject.zip" from the main "SentiTermProject.zip"
2. Unzip it at any folder location in the file system.
3. Go to Windows command prompt by typing "cmd" in Windows Run.
4. "cd" to the location where SentiProject.zip is unzipped.


Running "Check Polarity" Algorithm:-
Jar:- Senti_CheckPolarity.jar
Input:- garmin_nuvi_255W_gps.txt.data (Or any other file with ".data" extension, we have 5 topic data files in the same folder)
		garmin_nuvi_255W_gps.txt.data.ft (Manually selected comma separated feature file)
Intermediate Output File :- garmin_nuvi_255W_gps.txt.data.out (Tagged File with POS Tagger)
Output:- garmin_nuvi_255W_gps.txt.data.res
          See Output Console as well for results.
Command:- java -jar Senti_CheckPolarity.jar garmin_nuvi_255W_gps.txt.data 5

1. Run command with all 2 arguments "java -jar Senti_CheckPolarity.jar garmin_nuvi_255W_gps.txt.data 5". Giving 2 arguments as input is compulsary.
2. 2 arguments from command line can be e.g. "garmin_nuvi_255W_gps.txt.data 5" or "garmin_nuvi_255W_gps.txt.data -1". 
3. Description of 2 arguments.
   Argument 1 -> Data file name in package ".data" with all reviews in it and all sentences are separated with new line characters.
   Argument 2 -> Distance to search for Adjective around Noun. For 5 it is "X+5 to X-5". And "-1" if we do not want to keep this restriction.



Running "Naive Bayesian" Algorithm:-
Jar:- Senti_NBC.jar
Input:- bestwestern_hotel_sfo.txt.data (Or any other file with ".data" extension, we have 5 topic data files in the same folder)
		bestwestern_hotel_sfo.txt.data.gold (Manually agreed Gold standard File)
Intermediate Output File :- bestwestern_hotel_sfo.txt.data.arff (File generated after preprocessing)
Output:- See Output Console for results.
Command:- java -jar Senti_NBC.jar bestwestern_hotel_sfo.txt.data notsynonym
Prerequisite if you want to run with synonym:-Must install WordNet 2.1 from "http://wordnet.princeton.edu/wordnet/download/" and install at the location "C:/Program Files/WordNet/2.1/dict"

1. Run command with all 2 arguments "java -jar Senti_NBC.jar bestwestern_hotel_sfo.txt.data 5". Giving 2 arguments as input is compulsary.
2. 2 arguments from command line can be e.g. "bestwestern_hotel_sfo.txt.data synonym" or "bestwestern_hotel_sfo.txt.data notsynonym". 
3. Description of 2 arguments.
   Argument 1 -> Data file name in package ".data" with all reviews in it and all sentences are separated with new line characters.
   Argument 2 -> Adjectives comaprison to be done with "synonym" ot without synonym "notsynonym"-with this, prerequisite installation of WordNet 2.1 is not required.
   

Running "Summarization" for features:-
Jar:- Senti_Summarization.jar
Input:- bestwestern_hotel_sfo.txt.data.ft (Manually selected comma separated feature file)
		bestwestern_hotel_sfo.txt.data.res (Output result from CheckPolarity algorithm)
Output:- bestwestern_hotel_sfo.txt.data.sum 
		Also you can see Output Console for results.
Command:- java -jar Senti_Summarization.jar bestwestern_hotel_sfo.txt.data

1. Run command with 1 argument "java -jar Senti_Summarization.jar bestwestern_hotel_sfo.txt.data". Giving 1 argument as input is compulsary.
2. Description of 1 argument.
   Argument 1 -> Data file name in package ".data" with all reviews in it and all sentences are separated with new line characters.
   
   

For referring the code please unzip "Senti-NetBeansProjectwithCodeinIt.zip" file.